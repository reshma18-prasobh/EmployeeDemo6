﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Employee.Models;
using Microsoft.AspNetCore.Authorization;

namespace Employee.Controllers
{
    [Authorize]
    public class EmployeeClassesController : Controller
    {
        private readonly EmployeeContext _context;

        public EmployeeClassesController(EmployeeContext context)
        {
            _context = context;
        }

        // GET: EmployeeClasses
        public async Task<IActionResult> Index()
        {
            return View(await _context.EmployeeClass.ToListAsync());
        }

        // GET: EmployeeClasses/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeClass = await _context.EmployeeClass
                .FirstOrDefaultAsync(m => m.EmployeeId == id);
            if (employeeClass == null)
            {
                return NotFound();
            }

            return View(employeeClass);
        }

        // GET: EmployeeClasses/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: EmployeeClasses/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EmployeeId,FullName,EmployeeCode,Position,DateOfBirth")] EmployeeClass employeeClass)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employeeClass);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(employeeClass);
        }

        // GET: EmployeeClasses/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeClass = await _context.EmployeeClass.FindAsync(id);
            if (employeeClass == null)
            {
                return NotFound();
            }
            return View(employeeClass);
        }

        // POST: EmployeeClasses/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EmployeeId,FullName,EmployeeCode,Position,DateOfBirth")] EmployeeClass employeeClass)
        {
            if (id != employeeClass.EmployeeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employeeClass);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeClassExists(employeeClass.EmployeeId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employeeClass);
        }

        // GET: EmployeeClasses/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeClass = await _context.EmployeeClass
                .FirstOrDefaultAsync(m => m.EmployeeId == id);
            if (employeeClass == null)
            {
                return NotFound();
            }

            return View(employeeClass);
        }

        // POST: EmployeeClasses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employeeClass = await _context.EmployeeClass.FindAsync(id);
            _context.EmployeeClass.Remove(employeeClass);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeClassExists(int id)
        {
            return _context.EmployeeClass.Any(e => e.EmployeeId == id);
        }
    }
}
